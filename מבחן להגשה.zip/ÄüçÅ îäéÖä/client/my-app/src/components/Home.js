import React, { Component } from 'react'

export class home extends Component {
    render() {
        return (
            <div>
            <h1>Server Mangement  App</h1>
            <p style={{color:'green',fontFamily:'ariel',fontSize:'40px'}}>
             <b>
             Hello ,Here You Can Find  Information<br></br> About Servers,Hoisting and So On..
             Have Fun -:)
             </b>
                    
            </p>
            </div>
        )
    }
}

export default home;