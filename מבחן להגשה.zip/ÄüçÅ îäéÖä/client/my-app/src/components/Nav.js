import React from 'react';
import './Nav.css';
import {Link} from 'react-router-dom';

function Nav() {

    const navStyle = {
        color: 'blue',
        fontWeight:'bold',
        fontSize:'xx-large'

        
    }; 

  return (
    <nav>
        
        <ul className ="nav-links">
        <Link style={navStyle} to ='/Home'>
             <li>Home Page</li>
            </Link>
            <Link style={navStyle} to ='/server'>
             <li>server</li>
            </Link>
            <Link style={navStyle} to ='/server1'>
             <li>server1</li>
            </Link>
            <Link style={navStyle} to ='/server2'>
             <li>server2</li>
            </Link>
            <Link style={navStyle} to ='/server3'>
             <li>server3</li>
            </Link>

            <Link style={navStyle} to ='/server4'>
             <li>server4</li>
            </Link>
            <Link style={navStyle} to ='/server5'>
             <li>server5</li>
            </Link>
            
        </ul>
    </nav>
      
  );
}

export default Nav;
