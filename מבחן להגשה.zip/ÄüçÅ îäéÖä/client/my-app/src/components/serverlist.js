import React, { Component } from 'react';

 class servers extends Component {
    constructor () {
        super();
        this.state = {
            servers:[]
        }
};
        
   


    
    componentDidMount() {
        fetch ('http://localhost:5000/servers')
        .then(res => res.json())
        .then(servers => this.setState({servers}, () => console.log(' info fetched..',servers
         )));
    }




    render() {
        return (
            <div>
                <h1>All Servers</h1>
                
                <ul>
                 {this.state.servers.map(server =>
                  
                  <li key ={server.id}>    {server.server_name}   </li>
                                    
                                     

                  )}
              </ul>
                              
               


              
            </div>
        )
    }
}






export default servers
