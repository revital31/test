import React, { Component } from 'react';

 class server4 extends Component {
    constructor () {
        super();
        this.state = {
            servers:[]
        }
};
        
   


    
    componentDidMount() {
        fetch ('http://localhost:5000/server/4')
        .then(res => res.json())
        .then(servers => this.setState({servers}, () => console.log(' info fetched..',servers
         )));
    }




    render() {
        return (
            <div>
                <h1>server 4</h1>
                
                <ul>
                 {this.state.servers.map(server =>
                  
                  <li key ={server.id}>    {server.server_name}  {server.ip}  {server.hoisting_company}  {server.status}  {server.server_craetion_time} </li>
                                    
                                     

                  )}
              </ul>
                              
               


              
            </div>
        )
    }
}






export default server4
