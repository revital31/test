const express = require("express");
const app = express();
const {pool} = require('../pool/dbconnection');
const cors = require("cors");



//cors
app.use(
  cors({
    mode: "no-cors",
    origin: "http://localhost:3000",
  })
);




//return all 
app.route("/servers").get((req, res) => {
    pool.query("SELECT * FROM servers_1", (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });


  //return servers+compnies
  app.route("/server/comp").get((req, res) => {
    pool.query("SELECT server_name,hoisting_company FROM servers_1", (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });

    
//post request

app.route("/status").post((req, res) => {
  pool.query("UPDATE servers_1 SET  status = active WHERE id =4 ", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});
    


//return all servers

  //return all servers
  app.route("/server").get((req, res) => {
    pool.query("SELECT server_name FROM servers_1", (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });

  //return server by id
  
  app.route("/server/1").get((req, res) => {
    pool.query("SELECT * FROM servers_1 WHERE id='1' ", (err, results) => {
      if (err) throw err;
      res.json(results);
    })
  });


  app.route("/server/2").get((req, res) => {
    pool.query("SELECT * FROM servers_1 WHERE id='2' ", (err, results) => {
      if (err) throw err;
      res.json(results);
    })
  });

  app.route("/server/3").get((req, res) => {
    pool.query("SELECT * FROM servers_1 WHERE id='3' ", (err, results) => {
      if (err) throw err;
      res.json(results);
    })
  });


  app.route("/server/4").get((req, res) => {
    pool.query("SELECT * FROM servers_1 WHERE id='4' ", (err, results) => {
      if (err) throw err;
      res.json(results);
    })
  });


  app.route("/server/5").get((req, res) => {
    pool.query("SELECT * FROM servers_1 WHERE id='5' ", (err, results) => {
      if (err) throw err;
      res.json(results);
    })
  });
  
  
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`server started on port ${port}`));
